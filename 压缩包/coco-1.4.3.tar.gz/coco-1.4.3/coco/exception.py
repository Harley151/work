#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#


class PermissionFailed(Exception):
    pass


class NoAppException(Exception):
    pass
