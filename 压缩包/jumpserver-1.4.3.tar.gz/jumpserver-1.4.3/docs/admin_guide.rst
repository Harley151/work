管理文档
=========

这里介绍管理员功能。

.. toctree::
   :maxdepth: 1

   admin_instruction
   admin_user
   admin_asset
   admin_permission
   admin_work_center
   admin_session
   admin_system_settings
