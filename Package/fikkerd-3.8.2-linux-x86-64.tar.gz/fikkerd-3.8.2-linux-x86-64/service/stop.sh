#!/bin/sh

if [ -f "/sbin/service" ]; then
    /sbin/service fikkerd stop
else
    /usr/sbin/service fikkerd stop
fi
