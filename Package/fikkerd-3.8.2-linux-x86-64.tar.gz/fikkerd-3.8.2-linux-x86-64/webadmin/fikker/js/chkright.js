﻿if(getCookie("FIKKERSERRIONID")==undefined){
	delCookie("FIKKERSERRIONID");
	delCookie("FIKKERUSERTYPE");
	delCookie("clickTRID");
	if(parent){
		parent.location.href="login.htm";
	}else{
		location.href="login.htm";	//权限判断
	}
}