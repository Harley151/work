from django.test import TestCase


class StoragesTestCase(TestCase):
    def setUp(self):
        pass
