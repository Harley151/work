from django.apps import AppConfig


class AppsettingsConfig(AppConfig):
    name = 'appsettings'
